function RazaoSocial(){
    return(
      <span>
        Loja de Instrumentos Musicais
      </span>
    )
  }
  export default RazaoSocial;
  