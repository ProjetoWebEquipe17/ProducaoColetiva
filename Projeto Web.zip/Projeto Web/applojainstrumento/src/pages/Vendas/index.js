function Vendas() {
    return (
        <div>
            <h2>Esta é a página de nossas Vendas</h2>
        </div>
    )
}
export default Vendas;