function Home() {
    return (
        <div>
            <h2>Esta é a página Home</h2>
        </div>
    )
}
export default Home;