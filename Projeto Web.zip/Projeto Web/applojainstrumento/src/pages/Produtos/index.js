function Produtos() {
    return (
        <div>
            <h2>Esta é a página de nossos Produtos</h2>
        </div>
    )
}
export default Produtos;