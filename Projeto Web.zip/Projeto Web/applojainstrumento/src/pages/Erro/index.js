function Erro() {
    return (
        <div>
            <h2>Página não encontrada</h2>
        </div>
    )
}
export default Erro;